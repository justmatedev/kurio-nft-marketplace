import { test, expect } from '@playwright/test'
import {
  addNftToCart,
  disconnectSocket,
  goCheckoutConnected,
  loginAsAlice,
  reconnectSocket,
  resetMocks,
  setScenario,
} from './helpers'

test.describe('Tempo real e falhas', () => {
  test.beforeEach(async ({ page }) => {
    await resetMocks(page)
  })

  test('skeleton em carregamento lento', async ({ page }) => {
    await setScenario(page, 'slow')
    await page.goto('/')
    await expect(page.getByLabel('Carregando catálogo')).toBeVisible({ timeout: 5_000 })
    await expect(page.locator('#catalogo')).toBeVisible()
    await expect(page.locator('#catalogo h3').first()).toBeVisible({ timeout: 20_000 })
  })

  test('pagamento recusado', async ({ page }) => {
    await setScenario(page, 'payment-rejected')
    await addNftToCart(page, 'nft_004')
    await loginAsAlice(page)
    await goCheckoutConnected(page)
    await page.getByRole('button', { name: 'Confirmar compra' }).locator('visible=true').click()
    await expect(page).toHaveURL(/orders\//, { timeout: 20_000 })
    await expect(page.getByText(/Recusado|recusado/i).first()).toBeVisible({ timeout: 25_000 })
  })

  test('price-changed no checkout bloqueia confirmação', async ({ page }) => {
    await setScenario(page, 'price-changed')
    await addNftToCart(page, 'nft_001')
    await loginAsAlice(page)
    await page.goto('/checkout')
    await expect(page.getByRole('heading', { name: 'Perfil do colecionador' })).toBeVisible({
      timeout: 15_000,
    })
    await page.locator('#display-name, #m-display-name').locator('visible=true').fill('Alice Colecionadora')
    await page.locator('#username, #m-username').locator('visible=true').fill('alice')
    await page.locator('#email, #m-email').locator('visible=true').fill('alice@kurio.dev')
    await page.getByRole('radio').locator('visible=true').first().click()
    await page.getByRole('button', { name: 'Simular conexão' }).locator('visible=true').click()
    await expect(
      page.getByText(/Status da carteira: connected/).locator('visible=true'),
    ).toBeVisible()
    await expect(
      page.getByText(/Cotação desatualizada/i).locator('visible=true'),
    ).toBeVisible({ timeout: 15_000 })
    await expect(
      page.getByRole('button', { name: 'Confirmar compra' }).locator('visible=true'),
    ).toBeDisabled()
    await page.getByRole('button', { name: 'Aceitar novos valores' }).locator('visible=true').click()
    await expect(
      page.getByRole('button', { name: 'Confirmar compra' }).locator('visible=true'),
    ).toBeEnabled()
  })

  test('clique repetido cria um único pedido', async ({ page }) => {
    await addNftToCart(page, 'nft_001')
    await loginAsAlice(page)
    await goCheckoutConnected(page)
    let creations = 0
    page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/api/orders')) creations++ })
    const confirm = page.getByRole('button', { name: 'Confirmar compra' }).locator('visible=true')
    await confirm.evaluate(button => { (button as HTMLButtonElement).click(); (button as HTMLButtonElement).click() })
    await expect(page).toHaveURL(/\/orders\/ord_/, { timeout: 20_000 })
    expect(creations).toBe(1)
    expect(await page.evaluate(() => Object.keys(JSON.parse(localStorage.getItem('kurio:mock-store-v3')!).orders).length)).toBe(1)
    const url = page.url()
    const id = url.match(/\/orders\/(ord_[^/?#]+)/)?.[1]
    expect(id).toBeTruthy()
    await page.reload()
    await expect(page).toHaveURL(new RegExp(`/orders/${id}`))
  })

  test('order-timeout recupera o mesmo pedido', async ({ page }) => {
    await setScenario(page, 'order-timeout')
    await addNftToCart(page, 'nft_002')
    await loginAsAlice(page)
    await goCheckoutConnected(page)
    const started = Date.now()
    await page.getByRole('button', { name: 'Confirmar compra' }).locator('visible=true').click()
    await expect(page).toHaveURL(/\/orders\/ord_/, { timeout: 20_000 })
    expect(Date.now() - started).toBeGreaterThanOrEqual(8000)
    expect(await page.evaluate(() => Object.keys(JSON.parse(localStorage.getItem('kurio:mock-store-v3')!).orders).length)).toBe(1)
    const orderUrl = page.url()
    const id = orderUrl.match(/\/orders\/(ord_[^/?#]+)/)?.[1]
    expect(id).toBeTruthy()

    await expect(page.getByText(/Aguardando confirmação/i)).toBeVisible({ timeout: 10_000 })
    await page.reload()
    await expect(page).toHaveURL(new RegExp(`/orders/${id}`))
    await expect(
      page.getByRole('heading', { name: /Seus NFTs agora estão na sua carteira|Confirmado/i }),
    ).toBeVisible({ timeout: 30_000 })
  })

  test('eventos stale e duplicados são ignorados', async ({ page }) => {
    await page.goto('/nfts/nft_001')
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible()

    await expect
      .poll(async () => page.evaluate(() => typeof window.__KURIO_EMIT_NFT__ === 'function'))
      .toBe(true)

    await expect.poll(() => page.evaluate(() => window.__KURIO_SOCKET__?.connected)).toBe(true)
    const eventIds = await page.evaluate(async () => {
      for (const priceEth of ['0.001', '9.999']) {
        await fetch('/api/dev/emit-nft', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nftId: 'nft_001', overrides: { editionId: 'ed_001_50', priceEth } }) })
      }
      const history = await fetch('/api/dev/events').then(r => r.json())
      return history.items.map((e: { eventId: string }) => e.eventId) as string[]
    })
    await expect(page.getByText('9.999 ETH', { exact: true }).locator('visible=true').first()).toBeVisible()
    await page.evaluate(async ids => {
      for (const eventId of [ids[1], ids[0], ids[1]]) await fetch('/api/dev/replay', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ eventId }) })
    }, eventIds)
    await expect(page.getByText('9.999 ETH', { exact: true }).locator('visible=true').first()).toBeVisible()
    await expect(page.getByText('0.001 ETH', { exact: true })).toHaveCount(0)
  })

  test('skeleton no detalhe e resumo do carrinho', async ({ page }) => {
    await setScenario(page, 'slow')
    await page.goto('/nfts/nft_001')
    await expect(page.getByLabel('Carregando detalhe do NFT')).toBeVisible({ timeout: 5_000 })
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible({ timeout: 20_000 })

    await setScenario(page, 'slow')
    await page.goto('/cart')
    await expect(page.getByLabel(/Carregando carrinho|Carregando resumo/i).first()).toBeVisible({
      timeout: 5_000,
    })
  })

  test('disconnect e retomada de pedido pendente', async ({ page }) => {
    await setScenario(page, 'order-timeout')
    await addNftToCart(page, 'nft_003')
    await loginAsAlice(page)
    await goCheckoutConnected(page)
    await page.getByRole('button', { name: 'Confirmar compra' }).locator('visible=true').click()
    await expect(page).toHaveURL(/\/orders\/ord_/, { timeout: 20_000 })
    const id = page.url().match(/\/orders\/(ord_[^/?#]+)/)?.[1]
    expect(id).toBeTruthy()

    await expect(page.getByText(/Aguardando confirmação/i)).toBeVisible()
    await disconnectSocket(page)
    await page.waitForTimeout(300)
    await reconnectSocket(page)

    await expect(
      page.getByRole('heading', {
        name: /Seus NFTs agora estão na sua carteira|Confirmado|Pagamento recusado/i,
      }),
    ).toBeVisible({ timeout: 30_000 })
    await expect(page).toHaveURL(new RegExp(`/orders/${id}`))
  })
})
